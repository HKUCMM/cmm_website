module.exports.sample = (req, res) => {
    res.json({ "users": ["userOne", "userTwo", "userThree"] });
}